# Table of Contents plugin for Wordpress

## Overview

## Structure

## Usage

## License

## Draft
This is a plugin which uses a special template to display a sidebar, and that sidebar is an programmatic list of the h2, h3, h4s on the page, displayed with internal links, and which animates based on user's scroll position

There's a settings area in the main Wordpress menu on the left

There are page and post settings as well, to select the H2, H3 etc.

## Release Notes
1.1.0 - Allows a user to select the left or right side of the screen for display
1.1.1 - Custom border color, show a menu title, shortcode functionality

